package com.example.fragments

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.app.Activity
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.utils.RealPathUtil
import com.example.MainActivity
import com.example.R
import com.example.utils.RenameUtil
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import androidx.activity.result.contract.ActivityResultContracts
import com.example.utils.FreezeManager
import com.example.utils.PanelFileManager
import com.example.ui.GlassmorphicDialogHelper
import com.example.ui.PermissionPromptType

class HomeFragment : Fragment() {

    private lateinit var tvStatus: TextView
    private lateinit var tvTimer: TextView
    private lateinit var btnActivate: Button
    private lateinit var btnTogglePower: Button
    private lateinit var btnOpenGame: Button
    private lateinit var btnBoost: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var tvProgress: TextView
    private lateinit var tvVersion: TextView
    private lateinit var tvPing: TextView
    private lateinit var tvBattery: TextView
    private lateinit var tvFps: TextView
    private lateinit var tvPlaytimeToday: TextView
    private lateinit var tvPlaytimeYesterday: TextView

    private var isOn = false
    private var isActivationMode = false
    private var countDownTimer: CountDownTimer? = null
    private val timerUpdateInterval = 1000L

    private val freezeListener = object : FreezeManager.FreezeStateListener {
        override fun onFreezeStateChanged(isFrozen: Boolean, reason: String) {
            activity?.runOnUiThread {
                if (isAdded) {
                    if (isFrozen) {
                        Toast.makeText(context, "❄️ Server frozen by admin:\n$reason", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(context, "✨ Server unfrozen by admin!", Toast.LENGTH_SHORT).show()
                    }
                    updateUIState()
                }
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_home, container, false)
        tvStatus = view.findViewById(R.id.tv_status)
        tvStatus.setOnClickListener {
            Thread {
                val ctx = context ?: return@Thread
                val act = PanelFileManager.areFilesStaged(ctx)
                val (t1, t2) = PanelFileManager.getTargetPaths(ctx)
                val d1Exists = RenameUtil.checkDirExists(t1.trimEnd('/'))
                val d2Exists = RenameUtil.checkDirExists(t2.trimEnd('/'))
                val shizukuOk = RenameUtil.shizukuAvailable()
                val isModOn = PanelFileManager.isModOn(ctx)
                
                val msg = "System Diagnostics:\n\n" +
                        "• Shizuku Authorized: $shizukuOk\n" +
                        "• Files Activated (Staged): $act\n" +
                        "• Mod State: ${if (isModOn) "ON 🟢" else "OFF 🔴"}\n\n" +
                        "• Target Path 1:\n  $t1\n  (Dir Exists: $d1Exists)\n\n" +
                        "• Target Path 2:\n  $t2\n  (Dir Exists: $d2Exists)\n\n" +
                        "• Last Error/Log:\n  ${PanelFileManager.lastLog.ifEmpty { RenameUtil.lastError.ifEmpty { "None" } }}"
                requireActivity().runOnUiThread {
                    android.app.AlertDialog.Builder(requireContext(), androidx.appcompat.R.style.ThemeOverlay_AppCompat_Dialog)
                        .setTitle("System Diagnostics")
                        .setMessage(msg)
                        .setPositiveButton("OK", null)
                        .setNeutralButton("Re-Download Files") { _, _ ->
                            startDownloadActivation()
                        }
                        .show()
                }
            }.start()
        }
        tvTimer = view.findViewById(R.id.tv_timer)
        btnActivate = view.findViewById(R.id.btn_activate)
        btnTogglePower = view.findViewById(R.id.btn_toggle_power)
        btnOpenGame = view.findViewById(R.id.btn_open_game)
        btnBoost = view.findViewById(R.id.btn_boost)
        progressBar = view.findViewById(R.id.progress_bar)
        tvProgress = view.findViewById(R.id.tv_progress)
        tvVersion = view.findViewById(R.id.tv_version)
        tvPing = view.findViewById(R.id.tv_ping)
        tvBattery = view.findViewById(R.id.tv_battery)
        tvFps = view.findViewById(R.id.tv_fps)
        tvPlaytimeToday = view.findViewById(R.id.tv_playtime_today)
        tvPlaytimeYesterday = view.findViewById(R.id.tv_playtime_yesterday)

        try {
            val vers = resources.openRawResource(R.raw.version).bufferedReader().use { it.readText() }.trim()
            tvVersion.text = "v$vers"
        } catch (e: Exception) {
            tvVersion.text = "v1.0"
        }

        view.findViewById<Button>(R.id.btn_telegram).setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://t.me/xcel1_panel")))
        }
        view.findViewById<Button>(R.id.btn_instagram).setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://instagram.com/x_celestials")))
        }
        view.findViewById<Button>(R.id.btn_not_working).setOnClickListener {
            android.app.AlertDialog.Builder(requireContext(), android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("App Not Working?")
                .setMessage("If you are facing issues, you can follow the tutorial or contact admin for help.")
                .setPositiveButton("Tutorial") { _, _ ->
                    startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://x-link.vercel.app/hologram-tutorial")))
                }
                .setNegativeButton("Contact Admin") { _, _ ->
                    startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://instagram.com/x_celestials")))
                }
                .setNeutralButton("Cancel", null)
                .show()
        }

        btnActivate.setOnClickListener { 
            if (context?.let { FreezeManager.isCurrentlyFrozen(it) } == true) {
                val reason = context?.let { FreezeManager.getFreezeReason(it) } ?: "Maintenance in progress"
                Toast.makeText(context, "❄️ Server is currently frozen by admin:\n$reason", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            startDownloadActivation()
        }
        
        btnTogglePower.setOnClickListener {
            if (context?.let { FreezeManager.isCurrentlyFrozen(it) } == true) {
                val reason = context?.let { FreezeManager.getFreezeReason(it) } ?: "Maintenance in progress"
                Toast.makeText(context, "❄️ Server is currently frozen by admin:\n$reason", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            if (isOn) {
                handleTurnOff()
            } else {
                handleTurnOn()
            }
        }
        
        btnBoost.setOnClickListener {
            // Little bounce animation
            btnBoost.animate()
                .scaleX(0.9f).scaleY(0.9f)
                .setDuration(100)
                .withEndAction {
                    btnBoost.animate()
                        .scaleX(1f).scaleY(1f)
                        .setDuration(100)
                        .start()
                }
                .start()
                
            Thread {
                if (RenameUtil.useShizukuOps && RenameUtil.shizukuAvailable()) {
                    val success = RenameUtil.executeShizukuCommand("pm trim-caches 999999G")
                    requireActivity().runOnUiThread {
                        if (success) {
                            Toast.makeText(context, "Device Boosted! Caches cleared.", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "Failed to clear caches.", Toast.LENGTH_SHORT).show()
                        }
                    }
                } else {
                    requireActivity().runOnUiThread {
                        Toast.makeText(context, "Shizuku is required for Boost feature.", Toast.LENGTH_SHORT).show()
                    }
                }
            }.start()
        }
        
        btnOpenGame.setOnClickListener {
            if (context?.let { FreezeManager.isCurrentlyFrozen(it) } == true) {
                val reason = context?.let { FreezeManager.getFreezeReason(it) } ?: "Maintenance in progress"
                Toast.makeText(context, "❄️ Cannot open game: Server is currently frozen by admin.\n$reason", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            val prefs = requireActivity().getSharedPreferences(MainActivity.PREFS_NAME, 0)
            val userType = prefs.getString(MainActivity.KEY_USER_TYPE, null)
            val launchIntent = requireContext().packageManager.getLaunchIntentForPackage("com.dts.freefiremax")
            
            if (launchIntent == null) {
                Toast.makeText(context, "Free Fire MAX not found", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            if (userType == "NORMAL") {
                // Check usage stats permission
                val appOps = requireContext().getSystemService(android.content.Context.APP_OPS_SERVICE) as android.app.AppOpsManager
                val mode = appOps.unsafeCheckOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, 
                        android.os.Process.myUid(), requireContext().packageName)
                if (mode != android.app.AppOpsManager.MODE_ALLOWED) {
                    GlassmorphicDialogHelper.showPermissionPrompt(
                        requireActivity(),
                        PermissionPromptType.USAGE_ACCESS,
                        onPrimary = {
                            startActivity(Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS))
                        },
                        onSecondary = {
                            showUidSelectionDialog(launchIntent)
                        }
                    )
                    return@setOnClickListener
                }
                
                showUidSelectionDialog(launchIntent)
            } else {
                startActivity(launchIntent)
            }
        }
        
        view.findViewById<android.widget.ImageButton>(R.id.btn_refresh)?.setOnClickListener {
            updateUIState()
            fetchSystemStats(view)
            Toast.makeText(context, "Refreshed", Toast.LENGTH_SHORT).show()
        }

        fetchSystemStats(view)

        return view
    }

    private val pingHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val pingRunnable = object : Runnable {
        override fun run() {
            Thread {
                try {
                    val process = Runtime.getRuntime().exec("ping -c 1 -w 2 8.8.8.8")
                    val returnVal = process.waitFor()
                    if (returnVal == 0) {
                        val reader = java.io.BufferedReader(java.io.InputStreamReader(process.inputStream))
                        var time = "--"
                        for (line in reader.lines()) {
                            if (line.contains("time=")) {
                                time = line.substringAfter("time=").substringBefore(" ")
                                break
                            }
                        }
                        requireActivity().runOnUiThread { tvPing.text = "Ping: ${time}ms" }
                    } else {
                        requireActivity().runOnUiThread { tvPing.text = "Ping: Error" }
                    }
                } catch (e: Exception) {
                    requireActivity().runOnUiThread { tvPing.text = "Ping: Error" }
                }
            }.start()
            pingHandler.postDelayed(this, 3000)
        }
    }

    override fun onResume() {
        super.onResume()
        FreezeManager.registerListener(freezeListener)
        updateUIState()
        view?.let { fetchSystemStats(it) }
        startTimerUpdate()
        pingHandler.post(pingRunnable)
    }

    override fun onPause() {
        super.onPause()
        FreezeManager.unregisterListener(freezeListener)
        countDownTimer?.cancel()
        statusAnimator?.cancel()
        glowAnimator?.cancel()
        pingHandler.removeCallbacks(pingRunnable)
    }
    
    private fun showUidSelectionDialog(launchIntent: Intent) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_uid_selection, null)
        
        val dialog = android.app.AlertDialog.Builder(requireContext(), android.R.style.Theme_Translucent_NoTitleBar)
            .setView(dialogView)
            .create()
            
        dialog.window?.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT))
        
        val listView = dialogView.findViewById<android.widget.ListView>(R.id.list_uids)
        val progressBar = dialogView.findViewById<ProgressBar>(R.id.progress_loading_uids)
        val tvNoUids = dialogView.findViewById<TextView>(R.id.tv_no_uids)
        val btnCancel = dialogView.findViewById<Button>(R.id.btn_cancel_dialog)
        
        btnCancel.setOnClickListener {
            dialog.dismiss()
        }
        
        progressBar.visibility = View.VISIBLE
        listView.visibility = View.GONE
        tvNoUids.visibility = View.GONE
        
        dialog.show()
        
        Thread {
            val uids = RenameUtil.getGameUIDs()
            requireActivity().runOnUiThread {
                progressBar.visibility = View.GONE
                if (uids.isEmpty()) {
                    tvNoUids.visibility = View.VISIBLE
                } else {
                    listView.visibility = View.VISIBLE
                    val adapter = android.widget.ArrayAdapter(requireContext(), R.layout.item_uid, android.R.id.text1, uids)
                    listView.adapter = adapter
                    
                    listView.setOnItemClickListener { _, _, _, _ ->
                        dialog.dismiss()
                        executeGameLaunchSequence(launchIntent)
                    }
                }
            }
        }.start()
    }
    
    private fun executeGameLaunchSequence(launchIntent: Intent) {
        val startTime = System.currentTimeMillis()
        
        val progressDialog = android.app.AlertDialog.Builder(requireContext(), androidx.appcompat.R.style.ThemeOverlay_AppCompat_Dialog)
            .setTitle("Anti-Ban Active")
            .setMessage("Applying protections and launching game...")
            .setCancelable(false)
            .create()
        progressDialog.show()
        
        val activity = requireActivity() as MainActivity
        activity.executeTurnOnGlobal { success ->
            updateUIState()
            
            // Calculate remaining time to wait (min 3 seconds total)
            val elapsed = System.currentTimeMillis() - startTime
            val remainingWait = Math.max(0L, 3000L - elapsed)
            
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                progressDialog.dismiss()
                if (success) {
                    Toast.makeText(context, "Anti-Ban applied! Launching...", Toast.LENGTH_SHORT).show()
                    
                    // Start GameMonitorService
                    val serviceIntent = Intent(requireContext(), com.example.services.GameMonitorService::class.java)
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                        requireContext().startForegroundService(serviceIntent)
                    } else {
                        requireContext().startService(serviceIntent)
                    }
                    
                    startActivity(launchIntent)
                } else {
                    val err = RenameUtil.lastError.ifEmpty { "Please activate panel first." }
                    Toast.makeText(context, "Could not turn on: $err", Toast.LENGTH_LONG).show()
                }
            }, remainingWait)
        }
    }

    private var statusAnimator: android.animation.ObjectAnimator? = null
    private var glowAnimator: android.animation.ObjectAnimator? = null

    private fun updateUIState() {
        val ctx = context ?: return
        Thread {
            val isStaged = PanelFileManager.areFilesStaged(ctx)
            val isModActive = if (isStaged) PanelFileManager.isModOn(ctx) else false
            val isFrozen = FreezeManager.isCurrentlyFrozen(ctx)

            requireActivity().runOnUiThread {
                statusAnimator?.cancel()
                glowAnimator?.cancel()
                tvStatus.scaleX = 1f
                tvStatus.scaleY = 1f
                tvStatus.alpha = 1f
                btnTogglePower.scaleX = 1f
                btnTogglePower.scaleY = 1f
                btnTogglePower.alpha = 1f

                if (isFrozen) {
                    isOn = false
                    tvStatus.text = "Status: FROZEN ❄️"
                    tvStatus.setTextColor(android.graphics.Color.parseColor("#00E5FF"))
                    
                    btnTogglePower.text = "FROZEN ❄️"
                    btnTogglePower.backgroundTintList = android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#37474F"))
                    btnTogglePower.setTextColor(android.graphics.Color.parseColor("#90A4AE"))
                    btnTogglePower.isEnabled = false
                    btnTogglePower.visibility = View.VISIBLE
                    btnActivate.visibility = View.GONE
                } else if (!isStaged) {
                    isOn = false
                    btnActivate.visibility = View.VISIBLE
                    btnActivate.isEnabled = true
                    btnTogglePower.visibility = View.GONE

                    tvStatus.text = "Status: NOT ACTIVATED ⚠️"
                    tvStatus.setTextColor(android.graphics.Color.parseColor("#FFD740"))
                } else {
                    // Files are staged & activated
                    btnActivate.visibility = View.GONE
                    btnTogglePower.visibility = View.VISIBLE
                    btnTogglePower.isEnabled = true

                    if (isModActive) {
                        isOn = true
                        tvStatus.text = "Status: ON \uD83D\uDFE2" // Green circle
                        tvStatus.setTextColor(android.graphics.Color.parseColor("#00E676"))
                        
                        btnTogglePower.text = "TURN OFF"
                        btnTogglePower.backgroundTintList = android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#F44336"))
                        btnTogglePower.setTextColor(android.graphics.Color.WHITE)
                        
                        statusAnimator = android.animation.ObjectAnimator.ofPropertyValuesHolder(
                            tvStatus,
                            android.animation.PropertyValuesHolder.ofFloat(View.SCALE_X, 1.0f, 1.05f),
                            android.animation.PropertyValuesHolder.ofFloat(View.SCALE_Y, 1.0f, 1.05f)
                        ).apply {
                            duration = 800
                            repeatCount = android.animation.ObjectAnimator.INFINITE
                            repeatMode = android.animation.ObjectAnimator.REVERSE
                            start()
                        }
                        
                        glowAnimator = android.animation.ObjectAnimator.ofPropertyValuesHolder(
                            btnTogglePower,
                            android.animation.PropertyValuesHolder.ofFloat(View.ALPHA, 0.7f, 1.0f),
                            android.animation.PropertyValuesHolder.ofFloat(View.SCALE_X, 0.98f, 1.02f),
                            android.animation.PropertyValuesHolder.ofFloat(View.SCALE_Y, 0.98f, 1.02f)
                        ).apply {
                            duration = 1000
                            repeatCount = android.animation.ObjectAnimator.INFINITE
                            repeatMode = android.animation.ObjectAnimator.REVERSE
                            interpolator = android.view.animation.PathInterpolator(0.4f, 0.0f, 0.2f, 1.0f)
                            start()
                        }
                    } else {
                        isOn = false
                        tvStatus.text = "Status: OFF \uD83D\uDD34" // Red circle
                        tvStatus.setTextColor(android.graphics.Color.parseColor("#FF5252"))

                        btnTogglePower.text = "TURN ON"
                        btnTogglePower.backgroundTintList = android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#00E5FF"))
                        btnTogglePower.setTextColor(android.graphics.Color.parseColor("#151A22"))
                    }
                }
            }
        }.start()
    }

    private fun startTimerUpdate() {
        countDownTimer?.cancel()
        tvTimer.text = "Timer: Unlimited"
    }

    private fun startDownloadActivation() {
        val ctx = context ?: return
        if (FreezeManager.isCurrentlyFrozen(ctx)) {
            val reason = FreezeManager.getFreezeReason(ctx)
            Toast.makeText(ctx, "❄️ Server is currently frozen by admin:\n$reason", Toast.LENGTH_LONG).show()
            return
        }

        progressBar.visibility = View.VISIBLE
        progressBar.isIndeterminate = true
        tvProgress.visibility = View.VISIBLE
        tvProgress.text = "Connecting to Firebase..."
        btnActivate.isEnabled = false

        PanelFileManager.fetchManifestFromFirestore(
            context = ctx,
            onSuccess = { manifest ->
                requireActivity().runOnUiThread {
                    tvProgress.text = "Starting download of 4 files..."
                    progressBar.isIndeterminate = false
                    progressBar.progress = 0
                }

                PanelFileManager.downloadAndStageAllFiles(
                    context = ctx,
                    manifest = manifest,
                    onProgress = { status, percent ->
                        requireActivity().runOnUiThread {
                            tvProgress.text = status
                            progressBar.isIndeterminate = (percent <= 0)
                            progressBar.progress = percent
                        }
                    },
                    onComplete = { success, errorMsg ->
                        requireActivity().runOnUiThread {
                            progressBar.visibility = View.GONE
                            tvProgress.visibility = View.GONE
                            btnActivate.isEnabled = true

                            if (success) {
                                Toast.makeText(ctx, "Activation successful! All 4 files downloaded & saved.", Toast.LENGTH_LONG).show()
                                updateUIState()
                            } else {
                                val err = errorMsg ?: "Unknown error downloading files"
                                Toast.makeText(ctx, "Activation failed: $err", Toast.LENGTH_LONG).show()
                                android.app.AlertDialog.Builder(requireContext(), androidx.appcompat.R.style.ThemeOverlay_AppCompat_Dialog)
                                    .setTitle("Activation Error")
                                    .setMessage(err)
                                    .setPositiveButton("OK", null)
                                    .show()
                                updateUIState()
                            }
                        }
                    }
                )
            },
            onError = { err ->
                requireActivity().runOnUiThread {
                    progressBar.visibility = View.GONE
                    tvProgress.visibility = View.GONE
                    btnActivate.isEnabled = true
                    Toast.makeText(ctx, "Failed to load config: $err", Toast.LENGTH_LONG).show()
                    android.app.AlertDialog.Builder(requireContext(), androidx.appcompat.R.style.ThemeOverlay_AppCompat_Dialog)
                        .setTitle("Firestore Configuration Needed")
                        .setMessage(err)
                        .setPositiveButton("OK", null)
                        .show()
                    updateUIState()
                }
            }
        )
    }

    private fun handleTurnOn() {
        val activity = requireActivity() as MainActivity
        btnTogglePower.isEnabled = false
        activity.executeTurnOnGlobal { success ->
            btnTogglePower.isEnabled = true
            if (success) {
                Toast.makeText(context, "Mod turned ON", Toast.LENGTH_SHORT).show()
                startTimerUpdate()
            } else {
                val err = RenameUtil.lastError.ifEmpty { "Check destination folders." }
                Toast.makeText(context, "Failed to turn ON:\n$err", Toast.LENGTH_LONG).show()
                android.app.AlertDialog.Builder(requireContext(), androidx.appcompat.R.style.ThemeOverlay_AppCompat_Dialog)
                    .setTitle("Turn ON Error")
                    .setMessage(err)
                    .setPositiveButton("OK", null)
                    .show()
            }
            updateUIState()
        }
    }

    private fun handleTurnOff() {
        val activity = requireActivity() as MainActivity
        btnTogglePower.isEnabled = false
        activity.executeTurnOffGlobal { result ->
            btnTogglePower.isEnabled = true
            if (result == "SUCCESS") {
                Toast.makeText(context, "Mod turned OFF", Toast.LENGTH_SHORT).show()
            } else {
                val err = RenameUtil.lastError.ifEmpty { "Check destination folders." }
                Toast.makeText(context, "Failed to turn OFF:\n$err", Toast.LENGTH_LONG).show()
                android.app.AlertDialog.Builder(requireContext(), androidx.appcompat.R.style.ThemeOverlay_AppCompat_Dialog)
                    .setTitle("Turn OFF Error")
                    .setMessage(err)
                    .setPositiveButton("OK", null)
                    .show()
            }
            updateUIState()
            countDownTimer?.cancel()
            tvTimer.text = "Timer: --"
        }
    }

    private fun fetchSystemStats(view: View) {
        val prefs = requireActivity().getSharedPreferences(MainActivity.PREFS_NAME, 0)
        
        // Battery
        try {
            val bm = requireContext().getSystemService(android.content.Context.BATTERY_SERVICE) as android.os.BatteryManager
            val batLevel = bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
            tvBattery.text = "Battery: $batLevel%"
        } catch (e: Exception) {
            tvBattery.text = "Battery: --%"
        }
        
        // FPS
        val windowManager = requireContext().getSystemService(android.content.Context.WINDOW_SERVICE) as android.view.WindowManager
        val display = windowManager.defaultDisplay
        val refreshRate = display.refreshRate
        tvFps.text = "FPS: ${refreshRate.toInt()}"

        // Playtime
        try {
            val appOps = requireContext().getSystemService(android.content.Context.APP_OPS_SERVICE) as android.app.AppOpsManager
            val mode = appOps.unsafeCheckOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), requireContext().packageName)
            if (mode == android.app.AppOpsManager.MODE_ALLOWED || mode == android.app.AppOpsManager.MODE_DEFAULT) {
                val usageStatsManager = requireContext().getSystemService(android.content.Context.USAGE_STATS_SERVICE) as android.app.usage.UsageStatsManager
                val cal = java.util.Calendar.getInstance()
                // today
                cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
                cal.set(java.util.Calendar.MINUTE, 0)
                cal.set(java.util.Calendar.SECOND, 0)
                val todayStart = cal.timeInMillis
                val todayEnd = System.currentTimeMillis()
                
                var timeToday = 0L
                val eventsToday = usageStatsManager.queryEvents(todayStart, todayEnd)
                var lastTime = todayStart
                val event = android.app.usage.UsageEvents.Event()
                var isForeground = false
                var currentForegroundPkg: String? = null
                
                while (eventsToday.hasNextEvent()) {
                    eventsToday.getNextEvent(event)
                    
                    if (event.eventType == android.app.usage.UsageEvents.Event.ACTIVITY_RESUMED || event.eventType == 1) {
                        currentForegroundPkg = event.packageName
                    } else if (event.eventType == android.app.usage.UsageEvents.Event.ACTIVITY_PAUSED || event.eventType == 2 || event.eventType == 23) {
                        if (currentForegroundPkg == event.packageName) {
                            currentForegroundPkg = null
                        }
                    }

                    if (event.packageName == "com.dts.freefiremax") {
                        if (event.eventType == android.app.usage.UsageEvents.Event.ACTIVITY_RESUMED || event.eventType == 1) { // 1 is MOVE_TO_FOREGROUND
                            if (!isForeground) {
                                isForeground = true
                                lastTime = event.timeStamp
                            }
                        } else if (event.eventType == android.app.usage.UsageEvents.Event.ACTIVITY_PAUSED || event.eventType == 2 || event.eventType == 23) { // 2 is MOVE_TO_BACKGROUND
                            if (isForeground) {
                                isForeground = false
                                timeToday += (event.timeStamp - lastTime)
                            }
                        }
                    }
                }
                
                val isActuallyForeground = (currentForegroundPkg == "com.dts.freefiremax")
                
                if (isForeground) {
                    timeToday += (todayEnd - lastTime)
                }

                val hoursToday = timeToday / 3600000
                val minsToday = (timeToday % 3600000) / 60000
                tvPlaytimeToday.text = "Today: ${hoursToday}h ${minsToday}m"

                val tvGameStatus = view.findViewById<TextView>(R.id.tv_game_status)
                if (isActuallyForeground) {
                    tvGameStatus.text = "Active"
                    tvGameStatus.setTextColor(android.graphics.Color.parseColor("#4CAF50")) // Green
                } else {
                    tvGameStatus.text = "Inactive"
                    tvGameStatus.setTextColor(android.graphics.Color.parseColor("#EF4444")) // Red
                }

                // yesterday
                cal.add(java.util.Calendar.DAY_OF_YEAR, -1)
                val yesterdayStart = cal.timeInMillis
                val yesterdayEnd = todayStart
                
                var timeYesterday = 0L
                val eventsYesterday = usageStatsManager.queryEvents(yesterdayStart, yesterdayEnd)
                var lastTimeY = yesterdayStart
                isForeground = false
                while (eventsYesterday.hasNextEvent()) {
                    eventsYesterday.getNextEvent(event)
                    if (event.packageName == "com.dts.freefiremax") {
                        if (event.eventType == android.app.usage.UsageEvents.Event.ACTIVITY_RESUMED || event.eventType == 1) { 
                            if (!isForeground) {
                                isForeground = true
                                lastTimeY = event.timeStamp
                            }
                        } else if (event.eventType == android.app.usage.UsageEvents.Event.ACTIVITY_PAUSED || event.eventType == 2) { 
                            if (isForeground) {
                                isForeground = false
                                timeYesterday += (event.timeStamp - lastTimeY)
                            }
                        }
                    }
                }
                if (isForeground) {
                    timeYesterday += (yesterdayEnd - lastTimeY)
                }

                val hoursYest = timeYesterday / 3600000
                val minsYest = (timeYesterday % 3600000) / 60000
                tvPlaytimeYesterday.text = "Yesterday: ${hoursYest}h ${minsYest}m"

            } else {
                tvPlaytimeToday.text = "Tap to enable required permission"
                tvPlaytimeToday.setOnClickListener {
                    startActivity(Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS))
                }
                tvPlaytimeYesterday.text = "Stats hidden"
            }
        } catch (e: Exception) {
            tvPlaytimeToday.text = "Permission missing or feature not available"
        }
    }
}
